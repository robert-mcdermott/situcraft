# Methods: The Lung's results

## Data

A human lung section was profiled on the 10x Genomics Xenium platform [1] with the Xenium Human Lung Gene Expression panel (289 genes), and its output analyzed by Xenium Onboard Analysis 2.0.0 (xenium-2.0.0.10). The data are Xenium V1 human Lung, 2 FOVs (XOA 2.0, nucleus expansion 5 µm), published by 10x Genomics under CC BY 4.0 [2]. The instrument segmented 11,898 cells, all by nucleus expansion of 5.0 µm. Of 825,885 decoded transcripts, 746,213 were of the panel's genes with a quality score (qv, Phred-scaled) of at least 20; only these were counted, as by Xenium Onboard Analysis, and 98.0% of them were assigned to cells. The output bundle was read with SituCraft 0.8.0 (commit 2ca32c6) [3], whose own readers decoded every file, including the JPEG 2000 morphology images (ITU-T T.800), checked the files' consistency (0 fatal problems, 0 warnings, 3 notes), and recomputed 22 of the values the run recorded from its data (all agreeing).

## Cell types

The cells were clustered as scanpy's defaults do [3–8]: the cells with at least 10 gene transcripts, each scaled to the median total and log-transformed, and each gene scaled; 50 principal components; a graph of each cell's 15 nearest neighbors; and Leiden communities of modularity at a resolution of 1 (seed 20250), each cluster's markers found by the rank-sum test. This gave 29 clusters of 11,820 cells. The cells were mapped by UMAP from a spectral start [3, 7, 9, 10] (a minimum distance of 0.5, a spread of 1, umap-learn's number of epochs, 5 negative samples a positive one; seed 20250): a trustworthiness of 0.737, each cell's neighborhoods kept with a precision of 0.15 and a recall of 0.22. Cell types were defined by the marker set "Human lung (Xenium Human Lung panel)" (version 1: 26 labels at 3 levels, class, lineage and subtype; one of SituCraft's starter sets) [11, 12]. The cells were labeled from the marker set's markers [3, 4, 11–13]: each label's markers scored against control genes of similar expression, as scanpy's score_genes does (the genes cut into 25 bins by mean expression, 50 controls drawn from the bin of each of a label's markers, a label's lineage's markers left out of its controls; seed 20250), a cell taking a level's best label when it scored above 0 and led the next by 0.1, and a state when its markers scored 0.25 or more. The cells labeled: 47.0% at the class level, 11.5% at the lineage level and 1.0% at the subtype level.

## Spatial analysis

A graph of the cells was built: cells whose centroids are neighbors in the Delaunay triangulation (found with exact geometric predicates) were joined, edges longer than 50 µm left out [3, 14–17]; 35,472 edges, a mean degree of 6.0. Spatially variable genes were found by Moran's I of each gene over the cells' graph [3, 18–21], with row-standardized weights, each tested by 199 permutations (seed 20250), the 10 leading genes' local Moran's I by 199 permutations, the p-values adjusted by Benjamini and Hochberg's procedure: 162 of 289 genes were in a spatial pattern. The neighborhood enrichment of the class labels of "Human lung (Xenium Human Lung panel)" was measured over the cells' graph [3, 21–23]: for each pair of labels, the edges between their cells against those expected, each edge counting one, with a z-score and a p-value from 1,000 permutations of the labels (seed 20250), the p-values adjusted by Benjamini and Hochberg's procedure: 7 of 10 pairs differed from chance (adjusted p below 0.05).

## Figures

The figure "The Lung's results" was drawn by SituCraft [3] from the project's saved views and results (4 panels), each file written carrying a manifest of what each panel was drawn from.

## Software

The steps were run with Xenium Onboard Analysis (xenium-2.0.0.10) and SituCraft (0.8.0) [3]; this text was written from the project's record of each step by SituCraft 0.8.0.

## References

1. Janesick A, Shelansky R, Gottscho AD, et al. High resolution mapping of the tumor microenvironment using integrated single-cell, spatial and in situ analysis. Nat Commun 2023;14:8353. doi:10.1038/s41467-023-43458-x
2. 10x Genomics. Xenium V1 human Lung, 2 FOVs (XOA 2.0, nucleus expansion 5 µm). https://www.10xgenomics.com/support/software/xenium-onboard-analysis/latest/resources/xenium-example-data
3. McDermott R. SituCraft, version 0.8.0. https://github.com/robert-mcdermott/situcraft
4. Wolf FA, Angerer P, Theis FJ. SCANPY: large-scale single-cell gene expression data analysis. Genome Biol 2018;19:15. doi:10.1186/s13059-017-1382-0
5. Traag VA, Waltman L, van Eck NJ. From Louvain to Leiden: guaranteeing well-connected communities. Sci Rep 2019;9:5233. doi:10.1038/s41598-019-41695-z
6. Reichardt J, Bornholdt S. Statistical mechanics of community detection. Phys Rev E 2006;74:016110. doi:10.1103/PhysRevE.74.016110
7. McInnes L, Healy J, Melville J. UMAP: uniform manifold approximation and projection for dimension reduction. arXiv 2018. arXiv:1802.03426.
8. Mann HB, Whitney DR. On a test of whether one of two random variables is stochastically larger than the other. Ann Math Stat 1947;18:50–60. doi:10.1214/aoms/1177730491
9. Venna J, Kaski S. Neighborhood preservation in nonlinear projection methods: an experimental study. Artificial Neural Networks—ICANN 2001 2001:485–491. doi:10.1007/3-540-44668-0_68
10. Venna J, Peltonen J, Nybo K, Aidos H, Kaski S. Information retrieval perspective to nonlinear dimensionality reduction for data visualization. J Mach Learn Res 2010;11:451–490.
11. Travaglini KJ, Nabhan AN, Penland L, et al. A molecular cell atlas of the human lung from single-cell RNA sequencing. Nature 2020;587:619–625. doi:10.1038/s41586-020-2922-4
12. Sikkema L, Ramírez-Suástegui C, Strobl DC, et al. An integrated cell atlas of the lung in health and disease. Nat Med 2023;29:1563–1577. doi:10.1038/s41591-023-02327-2
13. Tirosh I, Izar B, Prakadan SM, et al. Dissecting the multicellular ecosystem of metastatic melanoma by single-cell RNA-seq. Science 2016;352:189–196. doi:10.1126/science.aad0501
14. Lee DT, Schachter BJ. Two algorithms for constructing a Delaunay triangulation. Int J Comput Inf Sci 1980;9:219–242. doi:10.1007/BF00977785
15. Bowyer A. Computing Dirichlet tessellations. Comput J 1981;24:162–166. doi:10.1093/comjnl/24.2.162
16. Watson DF. Computing the n-dimensional Delaunay tessellation with application to Voronoi polytopes. Comput J 1981;24:167–172. doi:10.1093/comjnl/24.2.167
17. Shewchuk JR. Adaptive precision floating-point arithmetic and fast robust geometric predicates. Discrete Comput Geom 1997;18:305–363. doi:10.1007/PL00009321
18. Moran PAP. Notes on continuous stochastic phenomena. Biometrika 1950;37:17–23. doi:10.1093/biomet/37.1-2.17
19. Cliff AD, Ord JK. Spatial Processes: Models and Applications. Pion, 1981.
20. Anselin L. Local indicators of spatial association—LISA. Geogr Anal 1995;27:93–115. doi:10.1111/j.1538-4632.1995.tb00338.x
21. Benjamini Y, Hochberg Y. Controlling the false discovery rate: a practical and powerful approach to multiple testing. J R Stat Soc B 1995;57:289–300. doi:10.1111/j.2517-6161.1995.tb02031.x
22. Schapiro D, Jackson HW, Raghuraman S, et al. histoCAT: analysis of cell phenotypes and interactions in multiplex image cytometry data. Nat Methods 2017;14:873–876. doi:10.1038/nmeth.4391
23. Palla G, Spitzer H, Klein M, et al. Squidpy: a scalable framework for spatial omics analysis. Nat Methods 2022;19:171–178. doi:10.1038/s41592-021-01358-2
