SituCraft certificate
=====================

Of:           The Lung's results (figure, fig-6819d73cc6474c91)
Project:      The Lung, as SituCraft 0.8.0 saved it, as of 2026-10-20T07:16:03.111Z (its last change)
Certified by: SituCraft 0.8.0 (commit 2ca32c6c3120)
Fingerprint:  4de5719d477c2e1c057ae00c367514bf779ebaf37b40dd7ce2f54a13017ed978
              (short form 4de5-719d-477c-2e1c; cite it with the result)

This certificate holds what the result rests on and what it reports: 1 bundle (their
files by SHA-256) and the 11 steps from them to it, in the order each was made from the
others: 7 steps SituCraft's jobs made (each job's kind, its spec by digest and the
18 files they wrote, by SHA-256) and 3 records of the page's own (by digest), each with
the numbers it reports; the project as it was; the record of each step and the methods.

What it proves
--------------
That these bundles, analyzed as these steps record, give these files and numbers: anyone with
the same bundles can make each step again and compare its files bit for bit (SituCraft gives
the same bits on every computer), and the record is the one certified (its fingerprint). It
does not prove that the result is right: that rests on the tissue, the panel and the methods'
assumptions, which the methods (methods.md) state.

To check it
-----------
Install SituCraft 0.8.0 or later (https://github.com/robert-mcdermott/situcraft/releases), then run:
  situcraft verify <this file> --data <a folder holding the bundles>
The bundles are found in the folder by their files' SHA-256, whatever their folders are named.
Exit status: 0 verified, 1 something differs (listed), 2 it could not be checked (a bundle or
a file missing). Another version of SituCraft can check it too, and says so: a step may then
differ where the version changed how it is made.

Contents
--------
  certificate.json             what was certified: the bundles, each step, the numbers reported
  project.json                 the project as it was
  record.md, record.json       each step from the bundles to the result
  methods.md, references.bib   the methods, written from the record, and their references
  artifacts/<ID>/manifest.json each step SituCraft's jobs made: its job, parameters and files
  manifest.json                every file of this archive with its SHA-256

Not made again
--------------
  - Step 1, xenium-lung-2fov: the instrument's output: its files are checked by their SHA-256.
  - Step 2, Instrument segmentation: the instrument's segmentation, read from its bundle: its files are checked by their SHA-256.
  - Step 5, Human lung (Xenium Human Lung panel), version 1: a person's work, recorded as made (its digest); what follows from it is made again.
  - Step 10, Lung classes: a person's work, recorded as made (its digest); what follows from it is made again.

Paths
-----
Where files lay on the computer that certified it is not kept: a bundle's folder is written
situcraft:bundle/<its dataset's ID>, any other file situcraft:file/<its name>.
