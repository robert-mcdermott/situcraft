# What made The Lung's results

Figure `fig-6819d73cc6474c91`, recorded by SituCraft 0.8.0: 11 steps, each after the steps it was made from.

## Steps

1. **xenium-lung-2fov** (Xenium output bundle `d-7c9a5b4068f345b6`, 2026-10-20). Method: Xenium Onboard Analysis, version 2.0.0. Xenium Human Lung Gene Expression, 11,898 cells, 825,885 transcripts, analysis 38f7f730-e4f3-4484-ac26-ec89cf061ac5. Read and checked by SituCraft: 0 fatal problems, 0 warnings; 22 of the 22 values the run recorded recomputed alike. Software: Xenium Onboard Analysis xenium-2.0.0.10. References: 1.

2. **Instrument segmentation** (segmentation `seg-2fec30e8d6bb2310839d`, 2026-10-20). Method: Xenium cell segmentation (Xenium Onboard Analysis), version xenium-2.0.0.10. From step 1. Software: Xenium Onboard Analysis xenium-2.0.0.10; situcraft 0.8.0. Chosen as the dataset's segmentation: "The instrument's segmentation: the dataset's only segmentation when it was added." (SituCraft, 2026-10-20). References: 1, 2.

3. **Clusters of Instrument segmentation, resolution 1** (clustering `clu-8b3e720f09c5d17b9e7b`, 2026-10-20). Method: SituCraft clustering, version 1. From steps 1, 2. Parameters: minTranscripts = 10; components = 50; neighbors = 15; resolution = 1. Seed: 20250. Software: situcraft 0.8.0. References: 2–7.

4. **Map of Clusters of Instrument segmentation, resolution 1** (map `emb-09f3e4a29309055ae73a`, 2026-10-20). Method: SituCraft UMAP, version 1. From steps 1–3. Parameters: minDist = 0.5; spread = 1; epochs = 0; negativeRate = 5. Seed: 20250. Software: situcraft 0.8.0. References: 2, 6, 8, 9.

5. **Human lung (Xenium Human Lung panel), version 1** (marker set `ms-d96c65a024d9-1`, 2026-10-20). Method: Marker set, version 1. Parameters: labels = 26; levels = Class, Lineage, Subtype; checksum = d96c65a024d9…; starter = lung. By the user. References: 10, 11.

6. **Labels of Clusters of Instrument segmentation, resolution 1 by Human lung (Xenium Human Lung panel)** (label set `lab-c25f4eaba2e9de96a2fe`, 2026-10-20). Method: SituCraft labels from markers, version 1. From steps 1–3, 5. Parameters: margin = 0.1; minimum = 0; state = 0.25; bins = 25; controls = 50; lineage = true; markers.name = Human lung (Xenium Human Lung panel); markers.checksum = d96c65a024d9…. Seed: 20250. Software: situcraft 0.8.0. References: 2, 3, 10–12.

7. **Delaunay graph of Instrument segmentation, edges to 50 µm** (cell graph `gra-0a5299a64a7cf1b80bf7`, 2026-10-20). Method: SituCraft cell graph, version 1. From steps 1, 2. Parameters: kind = delaunay; longest = 50. Software: situcraft 0.8.0. References: 2, 13–16.

8. **Moran's I of Instrument segmentation's genes, Delaunay graph of Instrument segmentation, edges to 50 µm** (spatial analysis `spa-300a3e216e6519ac93b4`, 2026-10-20). Method: SituCraft spatial analysis, version 1. From steps 1, 2, 7. Parameters: weights = row; permutations = 199; local = 10; localPermutations = 199. Seed: 20250. Software: situcraft 0.8.0. References: 2, 17–20.

9. **Neighborhood enrichment of Labels by Human lung (Xenium Human Lung panel): class, Delaunay graph of Instrument segmentation, edges to 50 µm** (spatial analysis `spa-57930e2da45e95e3094f`, 2026-10-20). Method: SituCraft spatial analysis, version 1. From steps 1, 2, 6, 7. Parameters: permutations = 1000; weight = edges. Seed: 20250. Software: situcraft 0.8.0. References: 2, 20–22.

10. **Lung classes** (saved view `v-dfbe75e4466442e7`, 2026-10-20). Method: Saved view. From steps 1, 6.

11. **The Lung's results** (figure `fig-6819d73cc6474c91`, 2026-10-20). Method: SituCraft figure, version 1. From steps 1, 3, 4, 6, 8–10. Parameters: size = double; width = 493.23; height = 446; panels = 4. References: 2.

## Software

- Xenium Onboard Analysis xenium-2.0.0.10
- situcraft 0.8.0

## References

1. Janesick A, Shelansky R, Gottscho AD, et al. High resolution mapping of the tumor microenvironment using integrated single-cell, spatial and in situ analysis. Nat Commun 2023;14:8353. doi:10.1038/s41467-023-43458-x
2. McDermott R. SituCraft, version 0.8.0. https://github.com/robert-mcdermott/situcraft
3. Wolf FA, Angerer P, Theis FJ. SCANPY: large-scale single-cell gene expression data analysis. Genome Biol 2018;19:15. doi:10.1186/s13059-017-1382-0
4. Traag VA, Waltman L, van Eck NJ. From Louvain to Leiden: guaranteeing well-connected communities. Sci Rep 2019;9:5233. doi:10.1038/s41598-019-41695-z
5. Reichardt J, Bornholdt S. Statistical mechanics of community detection. Phys Rev E 2006;74:016110. doi:10.1103/PhysRevE.74.016110
6. McInnes L, Healy J, Melville J. UMAP: uniform manifold approximation and projection for dimension reduction. arXiv 2018. arXiv:1802.03426.
7. Mann HB, Whitney DR. On a test of whether one of two random variables is stochastically larger than the other. Ann Math Stat 1947;18:50–60. doi:10.1214/aoms/1177730491
8. Venna J, Kaski S. Neighborhood preservation in nonlinear projection methods: an experimental study. Artificial Neural Networks—ICANN 2001 2001:485–491. doi:10.1007/3-540-44668-0\_68
9. Venna J, Peltonen J, Nybo K, Aidos H, Kaski S. Information retrieval perspective to nonlinear dimensionality reduction for data visualization. J Mach Learn Res 2010;11:451–490.
10. Travaglini KJ, Nabhan AN, Penland L, et al. A molecular cell atlas of the human lung from single-cell RNA sequencing. Nature 2020;587:619–625. doi:10.1038/s41586-020-2922-4
11. Sikkema L, Ramírez-Suástegui C, Strobl DC, et al. An integrated cell atlas of the lung in health and disease. Nat Med 2023;29:1563–1577. doi:10.1038/s41591-023-02327-2
12. Tirosh I, Izar B, Prakadan SM, et al. Dissecting the multicellular ecosystem of metastatic melanoma by single-cell RNA-seq. Science 2016;352:189–196. doi:10.1126/science.aad0501
13. Lee DT, Schachter BJ. Two algorithms for constructing a Delaunay triangulation. Int J Comput Inf Sci 1980;9:219–242. doi:10.1007/BF00977785
14. Bowyer A. Computing Dirichlet tessellations. Comput J 1981;24:162–166. doi:10.1093/comjnl/24.2.162
15. Watson DF. Computing the n-dimensional Delaunay tessellation with application to Voronoi polytopes. Comput J 1981;24:167–172. doi:10.1093/comjnl/24.2.167
16. Shewchuk JR. Adaptive precision floating-point arithmetic and fast robust geometric predicates. Discrete Comput Geom 1997;18:305–363. doi:10.1007/PL00009321
17. Moran PAP. Notes on continuous stochastic phenomena. Biometrika 1950;37:17–23. doi:10.1093/biomet/37.1-2.17
18. Cliff AD, Ord JK. Spatial Processes: Models and Applications. Pion, 1981.
19. Anselin L. Local indicators of spatial association—LISA. Geogr Anal 1995;27:93–115. doi:10.1111/j.1538-4632.1995.tb00338.x
20. Benjamini Y, Hochberg Y. Controlling the false discovery rate: a practical and powerful approach to multiple testing. J R Stat Soc B 1995;57:289–300. doi:10.1111/j.2517-6161.1995.tb02031.x
21. Schapiro D, Jackson HW, Raghuraman S, et al. histoCAT: analysis of cell phenotypes and interactions in multiplex image cytometry data. Nat Methods 2017;14:873–876. doi:10.1038/nmeth.4391
22. Palla G, Spitzer H, Klein M, et al. Squidpy: a scalable framework for spatial omics analysis. Nat Methods 2022;19:171–178. doi:10.1038/s41592-021-01358-2
