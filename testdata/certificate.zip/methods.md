# Methods: Expression compared: treated − control

## Data

The 2 sections (S01 and S02) were profiled on the 10x Genomics Xenium platform [1] with the Xenium Human Lung panel, and their outputs analyzed by Xenium Onboard Analysis 2.0.0 (xenium-2.0.0.10): 101 to 102 cells and 1,001 to 1,002 decoded transcripts a section, as the instrument segmented them. Each output bundle was read with SituCraft 0.8.0 (commit abcdef1) [2], whose own readers decoded every file, and checked: 0 fatal problems and 2 warnings in all, and 10 of the 10 values the runs recorded recomputed from their data alike.

## Cell types

The cells of each of S01 and S02 were clustered as scanpy's defaults do [2–4]: the cells with at least 10 gene transcripts, each scaled to the median total and log-transformed, and each gene scaled; 50 principal components; a graph of each cell's 15 nearest neighbors; and Leiden communities of modularity at a resolution of 1 (seed 20250), each cluster's markers found by the rank-sum test. This gave 5 clusters of 91 cells (S01) and 6 clusters of 92 cells (S02). Cell types were defined by the marker set "Lung" (version 1: 2 labels; one of SituCraft's starter sets) [5, 6]. The cells of each of S01 and S02 were labeled from the marker set's markers [2, 3, 5–7]: each label's markers scored against control genes of similar expression, as scanpy's score_genes does (the genes cut into 25 bins by mean expression, 50 controls drawn from the bin of each of a label's markers, a label's lineage's markers left out of its controls; seed 20250), a cell taking a level's best label when it scored above 0 and led the next by 0.1. The cells labeled: 89.0% at the class level (S01) and 89.1% at the class level (S02).

## Spatial analysis

A graph of the cells of each of S01 and S02 was built: cells whose centroids are neighbors in the Delaunay triangulation (found with exact geometric predicates) were joined, edges longer than 50 µm left out [2, 8]; 301 edges, a mean degree of 5.8 (S01) and 302 edges, a mean degree of 5.8 (S02). The neighborhood enrichment of the class labels of "Lung" (the cells of S01) was measured over the cells' graph [2, 9, 10]: for each pair of labels, the edges between their cells against those expected, each edge counting one, with a z-score and a p-value from 1,000 permutations of the labels (seed 7), the p-values adjusted by Benjamini and Hochberg's procedure: 2 of 3 pairs differed from chance (adjusted p below 0.05).

## Samples compared

The samples (2 samples: S01 and S02) were compared by the design "By condition" (version 1), which reads: Compares condition: treated against control. Each sample was summarized [2, 11]: its cells chosen (its section's, or its region's; never those a review excluded), labeled by "Lung" (T cell and B cell); each label's cells counted, with their share of the labeled cells and their density per mm² of the sample's tissue (its outline closed by 10 µm); its quality; and its pseudobulk, each label's cells' gene transcripts summed gene by gene. Niches were found across the samples together: each cell's 10 nearest labeled cells described by their labels' shares, and the cells grouped by k-means into 6 niches (10 starts, 4 seeds compared; seed 20250). Each label's pseudobulk was compared between the groups [2, 12, 13], with the subject as the unit: the genes every panel has; each label's rows with at least 10 of its cells; genes filtered by expression; TMM's library sizes and voom's weights; each gene's weighted linear model of the design, its variance moderated; each contrast's log2 fold change with its 95% interval and moderated t; and p-values adjusted by Benjamini and Hochberg's procedure over every label, gene and contrast tested. Of 50 tests, 1 had an adjusted p below 0.05: CD3E (T cell; treated − control; log2 fold change +1.20, adjusted p 0.012).

## Software

The steps were run with Xenium Onboard Analysis (xenium-2.0.0.10) and SituCraft (0.8.0) [2]; this text was written from the project's record of each step by SituCraft 0.8.0.

## References

1. Janesick A, Shelansky R, Gottscho AD, et al. High resolution mapping of the tumor microenvironment using integrated single-cell, spatial and in situ analysis. Nat Commun 2023;14:8353. doi:10.1038/s41467-023-43458-x
2. McDermott R. SituCraft, version 0.8.0. https://github.com/robert-mcdermott/situcraft
3. Wolf FA, Angerer P, Theis FJ. SCANPY: large-scale single-cell gene expression data analysis. Genome Biol 2018;19:15. doi:10.1186/s13059-017-1382-0
4. Traag VA, Waltman L, van Eck NJ. From Louvain to Leiden: guaranteeing well-connected communities. Sci Rep 2019;9:5233. doi:10.1038/s41598-019-41695-z
5. Travaglini KJ, Nabhan AN, Penland L, et al. A molecular cell atlas of the human lung from single-cell RNA sequencing. Nature 2020;587:619–625. doi:10.1038/s41586-020-2922-4
6. Doe J. An atlas of our own. J Atlases 2021;1:1. doi:10.9999/atlas
7. Tirosh I, Izar B, Prakadan SM, et al. Dissecting the multicellular ecosystem of metastatic melanoma by single-cell RNA-seq. Science 2016;352:189–196. doi:10.1126/science.aad0501
8. Lee DT, Schachter BJ. Two algorithms for constructing a Delaunay triangulation. Int J Comput Inf Sci 1980;9:219–242. doi:10.1007/BF00977785
9. Schapiro D, Jackson HW, Raghuraman S, et al. histoCAT: analysis of cell phenotypes and interactions in multiplex image cytometry data. Nat Methods 2017;14:873–876. doi:10.1038/nmeth.4391
10. Roe R. Unpublished permutations. 2025
11. Crowell HL, Soneson C, Germain P-L, et al. muscat detects subpopulation-specific state transitions from multi-sample multi-condition single-cell transcriptomics data. Nat Commun 2020;11:6077. doi:10.1038/s41467-020-19894-4
12. Smyth GK. Linear models and empirical Bayes methods for assessing differential expression in microarray experiments. Stat Appl Genet Mol Biol 2004;3:3. doi:10.2202/1544-6115.1027
13. Benjamini Y, Hochberg Y. Controlling the false discovery rate: a practical and powerful approach to multiple testing. J R Stat Soc B 1995;57:289–300. doi:10.1111/j.2517-6161.1995.tb02031.x
