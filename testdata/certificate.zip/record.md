# What made Expression compared: treated − control

Expression comparison `exp-1`, recorded by SituCraft 0.8.0: 15 steps, each after the steps it was made from.

## Steps

1–2. **Xenium output bundles, one for each of 2:** S01 (`d-1`); S02 (`d-2`). Method: Xenium Onboard Analysis, version 2.0.0. S01: Xenium Human Lung, 101 cells, 1,001 transcripts, analysis uuid-d-1. S02: Xenium Human Lung, 102 cells, 1,002 transcripts, analysis uuid-d-2. Read and checked by SituCraft: 0 fatal problems, 1 warnings; 5 of the 5 values the run recorded recomputed alike. Software: Xenium Onboard Analysis xenium-2.0.0.10. References: 1.

3–4. **Segmentations, one for each of 2:** Instrument segmentation, of S01 (`seg-1`), S02 (`seg-2`). Method: Xenium cell segmentation, version xenium-2.0.0.10. From steps 1, 2. Software: Xenium Onboard Analysis xenium-2.0.0.10; situcraft 0.8.0. Each: chosen as the dataset's segmentation: "The only one." (SituCraft, 2026-10-19). References: 1, 2.

5–6. **Clusterings, one for each of 2:** Clusters, resolution 1, of S01 (`clu-1`), S02 (`clu-2`). Method: SituCraft clustering, version 1. From steps 1–4. Parameters: minTranscripts = 10; components = 50; resolution = 1; neighbors = 15. Seed: 20250. Software: situcraft 0.8.0. References: 2–4.

7. **Lung, version 1** (marker set `ms-1`, 2026-10-19). Method: Marker set, version 1. Parameters: labels = 2; levels = Class; checksum = bbbbbbbbbbbb…; starter = lung. By the user. References: 5, 6.

8–9. **Label sets, one for each of 2:** Labels by Lung, of S01 (`lab-1`), S02 (`lab-2`). Method: SituCraft labels from markers, version 1. From steps 1–7. Parameters: margin = 0.1; minimum = 0; state = 0.25; bins = 25; controls = 50; lineage = true; markers.name = Lung; markers.checksum = aaaaaaaaaaaa…. Seed: 20250. Software: situcraft 0.8.0. References: 2, 3, 5–7.

10–11. **Cell graphs, one for each of 2:** Delaunay graph, of S01 (`gra-1`), S02 (`gra-2`). Method: SituCraft cell graph, version 1. From steps 1–4. Parameters: kind = delaunay; longest = 50. Software: situcraft 0.8.0. References: 2, 8.

12. **Neighborhood enrichment** (spatial analysis `spa-1`, 2026-10-19). Method: SituCraft spatial analysis, version 1. From steps 1, 3, 8, 10. Parameters: permutations = 1000; weight = edges. Seed: 7. Software: situcraft 0.8.0. References: 2, 9, 10.

13. **By condition, version 1** (design `des-1`, 2026-10-19). Method: Design, version 1. From steps 1, 2. Parameters: unit = subject; group = condition; reference = control; samples = 2; excluded = 0; model = Intercept, condition\[T.treated\]; df = 0. Compares condition: treated against control.

14. **Summary of 2 samples** (cohort summary `coh-1`, 2026-10-19). Method: SituCraft cohort summary, version 2. From steps 1–4, 7–12. Parameters: closing = 10; labels.name = Lung; labels.level = 0; labels.names = T cell, B cell; niches.neighbors = 10; niches.radius = 0; niches.niches = 6; niches.starts = 10; niches.seeds = 4. Seed: 20250. Software: situcraft 0.8.0. References: 2, 11.

15. **Expression compared: treated − control** (expression comparison `exp-1`, 2026-10-19). Method: SituCraft differential expression, version 1. From steps 13, 14. Parameters: level = 0.95; minCells = 10; design.name = By condition; design.version = 1; design.contrasts = treated − control. Software: situcraft 0.8.0. References: 2, 12, 13.

## Software

- Xenium Onboard Analysis xenium-2.0.0.10
- situcraft 0.8.0

## References

1. Janesick A, Shelansky R, Gottscho AD, et al. High resolution mapping of the tumor microenvironment using integrated single-cell, spatial and in situ analysis. Nat Commun 2023;14:8353. doi:10.1038/s41467-023-43458-x
2. McDermott R. SituCraft, version 0.8.0. https://github.com/robert-mcdermott/situcraft
3. Wolf FA, Angerer P, Theis FJ. SCANPY: large-scale single-cell gene expression data analysis. Genome Biol 2018;19:15. doi:10.1186/s13059-017-1382-0
4. Traag VA, Waltman L, van Eck NJ. From Louvain to Leiden: guaranteeing well-connected communities. Sci Rep 2019;9:5233. doi:10.1038/s41598-019-41695-z
5. Travaglini KJ, Nabhan AN, Penland L, et al. A molecular cell atlas of the human lung from single-cell RNA sequencing. Nature 2020;587:619–625. doi:10.1038/s41586-020-2922-4
6. Doe J. An atlas of our own. J Atlases 2021;1:1. doi:10.9999/atlas
7. Tirosh I, Izar B, Prakadan SM, et al. Dissecting the multicellular ecosystem of metastatic melanoma by single-cell RNA-seq. Science 2016;352:189–196. doi:10.1126/science.aad0501
8. Lee DT, Schachter BJ. Two algorithms for constructing a Delaunay triangulation. Int J Comput Inf Sci 1980;9:219–242. doi:10.1007/BF00977785
9. Schapiro D, Jackson HW, Raghuraman S, et al. histoCAT: analysis of cell phenotypes and interactions in multiplex image cytometry data. Nat Methods 2017;14:873–876. doi:10.1038/nmeth.4391
10. Roe R. Unpublished permutations. 2025
11. Crowell HL, Soneson C, Germain P-L, et al. muscat detects subpopulation-specific state transitions from multi-sample multi-condition single-cell transcriptomics data. Nat Commun 2020;11:6077. doi:10.1038/s41467-020-19894-4
12. Smyth GK. Linear models and empirical Bayes methods for assessing differential expression in microarray experiments. Stat Appl Genet Mol Biol 2004;3:3. doi:10.2202/1544-6115.1027
13. Benjamini Y, Hochberg Y. Controlling the false discovery rate: a practical and powerful approach to multiple testing. J R Stat Soc B 1995;57:289–300. doi:10.1111/j.2517-6161.1995.tb02031.x
